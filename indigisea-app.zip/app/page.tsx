"use client";

import { useEffect, useRef, useState } from "react";
import { openDB, type DBSchema } from "idb";

import { Button } from "@/components/ui/button";

interface RecordingItem {
  id: string;
  createdAt: number;
  durationMs: number;
  size: number;
  mimeType: string;
  blob: Blob;
}

interface RecorderDB extends DBSchema {
  recordings: {
    key: string;
    value: RecordingItem;
    indexes: {
      "by-createdAt": number;
    };
  };
}

const DB_NAME = "offline-recorder";
const STORE_NAME = "recordings";

const openRecorderDb = () =>
  openDB<RecorderDB>(DB_NAME, 1, {
    upgrade(db) {
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        const store = db.createObjectStore(STORE_NAME, { keyPath: "id" });
        store.createIndex("by-createdAt", "createdAt");
      }
    },
  });

const formatDuration = (durationMs: number) => {
  const seconds = Math.floor(durationMs / 1000);
  const minutes = Math.floor(seconds / 60);
  const remaining = seconds % 60;
  return `${minutes}:${remaining.toString().padStart(2, "0")}`;
};

const formatBytes = (bytes: number) => {
  if (bytes < 1024) return `${bytes} B`;
  const kb = bytes / 1024;
  if (kb < 1024) return `${kb.toFixed(1)} KB`;
  return `${(kb / 1024).toFixed(1)} MB`;
};

const extensionFor = (mimeType: string) => {
  if (mimeType.includes("mp4")) return "mp4";
  if (mimeType.includes("ogg")) return "ogg";
  if (mimeType.includes("wav")) return "wav";
  return "webm";
};

export default function Page() {
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const chunksRef = useRef<BlobPart[]>([]);
  const recordingStartRef = useRef<number>(0);

  const [isSupported, setIsSupported] = useState(false);
  const [isOnline, setIsOnline] = useState(true);
  const [isRecording, setIsRecording] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [activeDurationMs, setActiveDurationMs] = useState(0);
  const [recordings, setRecordings] = useState<RecordingItem[]>([]);
  const [recordingUrls, setRecordingUrls] = useState<Record<string, string>>({});
  const [error, setError] = useState<string | null>(null);

  const cleanupStream = () => {
    streamRef.current?.getTracks().forEach((track) => track.stop());
    streamRef.current = null;
  };

  const loadRecordings = async () => {
    const db = await openRecorderDb();
    const all = await db.getAll(STORE_NAME);
    setRecordings(all.sort((a, b) => b.createdAt - a.createdAt));
  };

  useEffect(() => {
    setIsSupported(
      typeof window !== "undefined" &&
        "mediaDevices" in navigator &&
        typeof window.MediaRecorder !== "undefined",
    );

    const updateOnlineState = () => setIsOnline(navigator.onLine);
    updateOnlineState();
    window.addEventListener("online", updateOnlineState);
    window.addEventListener("offline", updateOnlineState);

    void loadRecordings().catch(() => {
      setError("Could not load saved recordings.");
    });

    return () => {
      window.removeEventListener("online", updateOnlineState);
      window.removeEventListener("offline", updateOnlineState);
      cleanupStream();
      if (mediaRecorderRef.current?.state === "recording") {
        mediaRecorderRef.current.stop();
      }
    };
  }, []);

  useEffect(() => {
    if (!isRecording) {
      setActiveDurationMs(0);
      return;
    }

    const interval = window.setInterval(() => {
      setActiveDurationMs(Date.now() - recordingStartRef.current);
    }, 250);

    return () => {
      window.clearInterval(interval);
    };
  }, [isRecording]);

  useEffect(() => {
    const nextUrls: Record<string, string> = {};
    for (const recording of recordings) {
      nextUrls[recording.id] = URL.createObjectURL(recording.blob);
    }
    setRecordingUrls(nextUrls);

    return () => {
      for (const url of Object.values(nextUrls)) {
        URL.revokeObjectURL(url);
      }
    };
  }, [recordings]);

  const startRecording = async () => {
    setError(null);
    if (!isSupported || isRecording || isSaving) {
      return;
    }

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;

      const preferredTypes = ["audio/webm;codecs=opus", "audio/webm", "audio/mp4"];
      const mimeType = preferredTypes.find((candidate) => MediaRecorder.isTypeSupported(candidate));
      const mediaRecorder = mimeType
        ? new MediaRecorder(stream, { mimeType })
        : new MediaRecorder(stream);

      chunksRef.current = [];
      mediaRecorderRef.current = mediaRecorder;

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          chunksRef.current.push(event.data);
        }
      };

      mediaRecorder.onstop = async () => {
        setIsSaving(true);
        try {
          const blob = new Blob(chunksRef.current, {
            type: mediaRecorder.mimeType || "audio/webm",
          });

          if (blob.size === 0) {
            setError("Recording was empty. Please try again.");
            return;
          }

          const newItem: RecordingItem = {
            id: crypto.randomUUID(),
            createdAt: Date.now(),
            durationMs: Date.now() - recordingStartRef.current,
            size: blob.size,
            mimeType: blob.type,
            blob,
          };

          const db = await openRecorderDb();
          await db.put(STORE_NAME, newItem);
          await loadRecordings();
        } catch {
          setError("Could not save this recording.");
        } finally {
          cleanupStream();
          chunksRef.current = [];
          setIsSaving(false);
        }
      };

      recordingStartRef.current = Date.now();
      mediaRecorder.start();
      setIsRecording(true);
    } catch {
      cleanupStream();
      setError("Microphone access was denied or unavailable.");
    }
  };

  const stopRecording = () => {
    const mediaRecorder = mediaRecorderRef.current;
    if (!mediaRecorder || mediaRecorder.state !== "recording") {
      return;
    }

    setIsRecording(false);
    mediaRecorder.stop();
  };

  const deleteRecording = async (id: string) => {
    try {
      const db = await openRecorderDb();
      await db.delete(STORE_NAME, id);
      await loadRecordings();
    } catch {
      setError("Could not delete recording.");
    }
  };

  return (
    <main className="min-h-svh bg-[radial-gradient(circle_at_top,_hsl(158_64%_95%),_transparent_52%),linear-gradient(180deg,_hsl(160_55%_98%),_hsl(195_35%_95%))] px-4 py-8">
      <div className="mx-auto flex w-full max-w-3xl flex-col gap-6 rounded-3xl border border-black/5 bg-white/80 p-6 shadow-lg backdrop-blur-sm">
        <header className="space-y-2">
          <p className="text-xs font-semibold tracking-[0.14em] text-slate-600 uppercase">
            Offline-Only Recorder
          </p>
          <h1 className="text-3xl font-semibold tracking-tight text-slate-900">
            Indigisea Voice Archive
          </h1>
          <p className="max-w-2xl text-sm text-slate-700">
            Record, replay, and download clips with no server required. Everything is stored on
            this device using IndexedDB.
          </p>
          <p className="text-xs text-slate-600">
            Network status: <span className="font-medium">{isOnline ? "Online" : "Offline"}</span>
          </p>
        </header>

        {!isSupported ? (
          <p className="rounded-xl border border-amber-300 bg-amber-50 p-3 text-sm text-amber-900">
            This browser does not support audio recording. Try a recent Chrome, Edge, or Safari
            version.
          </p>
        ) : null}

        {error ? (
          <p className="rounded-xl border border-red-300 bg-red-50 p-3 text-sm text-red-900">
            {error}
          </p>
        ) : null}

        <section className="grid gap-3 rounded-2xl border border-slate-200 bg-white p-4 sm:grid-cols-[1fr_auto_auto] sm:items-center">
          <div className="text-sm text-slate-700">
            {isRecording ? (
              <>
                Recording now: <span className="font-semibold">{formatDuration(activeDurationMs)}</span>
              </>
            ) : (
              "Ready to record"
            )}
          </div>
          <Button
            onClick={() => {
              void startRecording();
            }}
            disabled={!isSupported || isRecording || isSaving}
            className="h-10 bg-emerald-700 px-4 text-white hover:bg-emerald-800"
          >
            Start
          </Button>
          <Button
            onClick={stopRecording}
            disabled={!isRecording}
            variant="destructive"
            className="h-10 px-4"
          >
            Stop
          </Button>
        </section>

        <section className="space-y-3">
          <h2 className="text-sm font-semibold tracking-[0.12em] text-slate-600 uppercase">
            Saved Recordings
          </h2>

          {recordings.length === 0 ? (
            <p className="rounded-xl border border-dashed border-slate-300 bg-white/70 p-4 text-sm text-slate-600">
              No recordings saved yet.
            </p>
          ) : (
            <ul className="space-y-3">
              {recordings.map((recording) => {
                const src = recordingUrls[recording.id];
                return (
                  <li
                    key={recording.id}
                    className="space-y-3 rounded-2xl border border-slate-200 bg-white p-4"
                  >
                    <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-slate-600">
                      <span>{new Date(recording.createdAt).toLocaleString()}</span>
                      <span>
                        {formatDuration(recording.durationMs)} • {formatBytes(recording.size)}
                      </span>
                    </div>

                    {src ? <audio className="w-full" controls src={src} /> : null}

                    <div className="flex flex-wrap gap-2">
                      <a
                        className="inline-flex h-8 items-center rounded-lg border border-slate-300 px-3 text-sm font-medium text-slate-800 transition hover:bg-slate-100"
                        href={src}
                        download={`recording-${recording.createdAt}.${extensionFor(recording.mimeType)}`}
                      >
                        Download
                      </a>
                      <Button
                        variant="ghost"
                        className="h-8 text-sm text-red-700 hover:bg-red-100 hover:text-red-800"
                        onClick={() => {
                          void deleteRecording(recording.id);
                        }}
                      >
                        Delete
                      </Button>
                    </div>
                  </li>
                );
              })}
            </ul>
          )}
        </section>
      </div>
    </main>
  );
}
